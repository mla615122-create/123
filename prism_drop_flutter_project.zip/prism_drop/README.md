# Prism Drop: Physics Rush (Flutter + Flame)

## كيف تحصل على ملف `.apk` و `.aab` بسهولة؟ (How to build APK & AAB)

### الطريقة الأولى: بدون تثبيت أي برامج على جهازك (عبر GitHub Actions مجاناً)
المشروع يحتوي جاهزاً على ملف البناء السحابي `.github/workflows/build_apk_aab.yml`:
1. قم بإنشاء مستودع (Repository) جديد على حسابك في **GitHub**.
2. ارفع محتويات هذا المجلد بالكامل إلى المستودع.
3. ادخل إلى تبويب **Actions** في GitHub، وستجد عملية البناء (**Build Android APK & Google Play AAB**) تعمل تلقائياً.
4. بعد انتهاء البناء (حوالي 3 دقائق)، قم بتحميل الملفين الجاهزين مباشرة:
   - `prism-drop-release-apk` (ملف `app-release.apk` لتثبيته وتجربته مباشرة على هاتفك الأندرويد).
   - `prism-drop-release-aab` (ملف `app-release.aab` المتوافق مع Google Play 2026، API 35، و16KB Page Alignment لرفعه على متجر جوجل بلاي).

### الطريقة الثانية: عبر جهازك (Terminal / Android Studio)
إذا كان لديك Flutter مثبتاً على جهازك، افتح موجه الأوامر (Terminal) داخل هذا المجلد ونفذ:

```bash
# 1. استكمال ملفات المشروع وتحميل المكتبات
flutter create --org com.studio --project-name prism_drop .
flutter pub get

# 2. استخراج ملف APK لتثبيته على الموبايل مباشرة
flutter build apk --release

# 3. استخراج ملف AAB لرفعه على Google Play Console
flutter build appbundle --release --obfuscate --split-debug-info=build/app/outputs/symbols
```

ستجد الملفات الناتجة في المسارات التالية:
- **ملف APK للتثبيت المباشر:** `build/app/outputs/flutter-apk/app-release.apk`
- **ملف AAB لمتجر جوجل بلاي:** `build/app/outputs/bundle/release/app-release.aab`
