import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/iap_service.dart';
import '../services/storage_service.dart';

/// Immutable snapshot of the player's HUD, session progress, and settings.
@immutable
class GameSessionState {
  final int score;
  final int highScore;
  final int coins;
  final int sessionCoins;
  final int combo;
  final int nextOrbTier;
  final bool soundEnabled;
  final bool hapticsEnabled;
  final bool adsRemoved;
  final bool secondChanceUsed;
  final bool isNewHighScore;

  const GameSessionState({
    required this.score,
    required this.highScore,
    required this.coins,
    required this.sessionCoins,
    required this.combo,
    required this.nextOrbTier,
    required this.soundEnabled,
    required this.hapticsEnabled,
    required this.adsRemoved,
    required this.secondChanceUsed,
    required this.isNewHighScore,
  });

  factory GameSessionState.initial() {
    final storage = StorageService.instance;
    return GameSessionState(
      score: 0,
      highScore: storage.highScore,
      coins: storage.coins,
      sessionCoins: 0,
      combo: 1,
      nextOrbTier: 1,
      soundEnabled: storage.soundEnabled,
      hapticsEnabled: storage.hapticsEnabled,
      adsRemoved: storage.adsRemoved,
      secondChanceUsed: false,
      isNewHighScore: false,
    );
  }

  GameSessionState copyWith({
    int? score,
    int? highScore,
    int? coins,
    int? sessionCoins,
    int? combo,
    int? nextOrbTier,
    bool? soundEnabled,
    bool? hapticsEnabled,
    bool? adsRemoved,
    bool? secondChanceUsed,
    bool? isNewHighScore,
  }) {
    return GameSessionState(
      score: score ?? this.score,
      highScore: highScore ?? this.highScore,
      coins: coins ?? this.coins,
      sessionCoins: sessionCoins ?? this.sessionCoins,
      combo: combo ?? this.combo,
      nextOrbTier: nextOrbTier ?? this.nextOrbTier,
      soundEnabled: soundEnabled ?? this.soundEnabled,
      hapticsEnabled: hapticsEnabled ?? this.hapticsEnabled,
      adsRemoved: adsRemoved ?? this.adsRemoved,
      secondChanceUsed: secondChanceUsed ?? this.secondChanceUsed,
      isNewHighScore: isNewHighScore ?? this.isNewHighScore,
    );
  }
}

class GameStateNotifier extends StateNotifier<GameSessionState> {
  GameStateNotifier() : super(GameSessionState.initial()) {
    IapService.instance.onEntitlementGranted = () {
      state = state.copyWith(adsRemoved: true);
    };
  }

  void resetSession({int initialTier = 1}) {
    state = state.copyWith(
      score: 0,
      sessionCoins: 0,
      combo: 1,
      nextOrbTier: initialTier,
      secondChanceUsed: false,
      isNewHighScore: false,
    );
  }

  void addScoreAndCoins({
    required int points,
    required int earnedCoins,
    required int combo,
  }) {
    final int updatedScore = state.score + points;
    final bool beatHigh = updatedScore > state.highScore;
    final int updatedHigh = beatHigh ? updatedScore : state.highScore;
    final int updatedTotalCoins = state.coins + earnedCoins;

    if (beatHigh) {
      StorageService.instance.setHighScore(updatedHigh);
    }
    if (earnedCoins > 0) {
      StorageService.instance.setCoins(updatedTotalCoins);
    }

    state = state.copyWith(
      score: updatedScore,
      highScore: updatedHigh,
      coins: updatedTotalCoins,
      sessionCoins: state.sessionCoins + earnedCoins,
      combo: combo,
      isNewHighScore: beatHigh || state.isNewHighScore,
    );
  }

  void resetCombo() {
    if (state.combo != 1) {
      state = state.copyWith(combo: 1);
    }
  }

  void setNextOrbTier(int tier) {
    state = state.copyWith(nextOrbTier: tier);
  }

  void markSecondChanceUsed() {
    state = state.copyWith(secondChanceUsed: true);
  }

  void doubleSessionCoins() {
    final int bonus = state.sessionCoins;
    if (bonus <= 0) return;
    final int newTotal = state.coins + bonus;
    StorageService.instance.setCoins(newTotal);
    state = state.copyWith(
      coins: newTotal,
      sessionCoins: state.sessionCoins * 2,
    );
  }

  Future<void> toggleSound() async {
    final bool next = !state.soundEnabled;
    await StorageService.instance.setSoundEnabled(next);
    state = state.copyWith(soundEnabled: next);
  }

  Future<void> toggleHaptics() async {
    final bool next = !state.hapticsEnabled;
    await StorageService.instance.setHapticsEnabled(next);
    state = state.copyWith(hapticsEnabled: next);
  }
}

final gameStateProvider =
    StateNotifierProvider<GameStateNotifier, GameSessionState>(
  (ref) => GameStateNotifier(),
);
