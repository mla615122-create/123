import 'dart:math' as math;
import 'package:flame/components.dart';
import 'package:flame/events.dart';
import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import '../services/ad_manager.dart';
import '../services/audio_synthesizer_service.dart';
import '../services/storage_service.dart';
import '../state/game_state_notifier.dart';
import 'components/aim_guide_component.dart';
import 'components/arena_boundary.dart';
import 'components/bumper_obstacle.dart';
import 'components/orb_component.dart';
import 'effects/particle_factory.dart';

/// Core 2D physics game engine built on Flame.
/// Uses deterministic sub-stepped impulse physics (4 sub-steps per frame)
/// for rock-solid stacking, bumper deflection, and chain-reaction merges at
/// 60-120 FPS without native C++ Box2D bridge overhead.
class PrismDropGame extends FlameGame
    with HasCollisionDetection, PanDetector, TapCallbacks {
  static const String overlayMainMenu = 'MainMenu';
  static const String overlayHud = 'Hud';
  static const String overlayPause = 'Pause';
  static const String overlayGameOver = 'GameOver';

  final GameStateNotifier stateNotifier;

  PrismDropGame({required this.stateNotifier});

  final math.Random _rng = math.Random();
  final List<OrbComponent> _orbs = [];
  final List<BumperObstacle> _bumpers = [];

  Rect _arenaRect = Rect.zero;
  double _dangerLineY = 160.0;
  double _spawnY = 122.0;
  double _aimX = 200.0;

  int _currentDropTier = 1;
  int _nextDropTier = 2;
  double _dropCooldown = 0.0;
  double _comboTimer = 0.0;
  int _currentCombo = 1;
  bool _isGameRunning = false;
  bool _isDangerWarningActive = false;

  static const double _gravity = 980.0;
  static const double _wallRestitution = 0.42;
  static const double _orbRestitution = 0.35;
  static const double _bumperRestitution = 0.78;
  static const int _physicsSubSteps = 4;

  @override
  Color backgroundColor() => const Color(0xFF070B14);

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _recalculateArenaMetrics(size);

    add(
      ArenaBoundary(
        getArenaRect: () => _arenaRect,
        getDangerLineY: () => _dangerLineY,
        isDangerActive: () => _isDangerWarningActive,
      ),
    );

    add(
      AimGuideComponent(
        getAimX: () => _aimX,
        getSpawnY: () => _spawnY,
        getFloorY: () => _arenaRect.bottom,
        getCurrentTier: () => _currentDropTier,
        canDrop: () => _isGameRunning && _dropCooldown <= 0.0,
      ),
    );

    _rebuildBumpers();
  }

  @override
  void onGameResize(Vector2 size) {
    super.onGameResize(size);
    _recalculateArenaMetrics(size);
    _rebuildBumpers();
  }

  void _recalculateArenaMetrics(Vector2 canvasSize) {
    final double horizontalMargin = (canvasSize.x * 0.05).clamp(14.0, 28.0);
    final double topInset = (canvasSize.y * 0.16).clamp(110.0, 165.0);
    // Reserve bottom space for adaptive Banner Ad (64px) + safe padding
    final double bottomInset = StorageService.instance.adsRemoved ? 28.0 : 84.0;

    _arenaRect = Rect.fromLTRB(
      horizontalMargin,
      topInset,
      canvasSize.x - horizontalMargin,
      canvasSize.y - bottomInset,
    );
    _dangerLineY = _arenaRect.top + 68.0;
    _spawnY = _arenaRect.top + 30.0;
    _aimX = _aimX.clamp(_arenaRect.left + 28.0, _arenaRect.right - 28.0);
  }

  void _rebuildBumpers() {
    for (final bumper in _bumpers) {
      bumper.removeFromParent();
    }
    _bumpers.clear();

    if (_arenaRect.width <= 0) return;

    final double centerX = _arenaRect.center.dx;
    final double midY = _arenaRect.top + _arenaRect.height * 0.42;

    final List<BumperObstacle> created = [
      BumperObstacle(
        position: Vector2(centerX - _arenaRect.width * 0.24, midY),
        radius: 15.0,
      ),
      BumperObstacle(
        position: Vector2(centerX + _arenaRect.width * 0.24, midY),
        radius: 15.0,
      ),
    ];

    for (final bumper in created) {
      _bumpers.add(bumper);
      add(bumper);
    }
  }

  /// Starts or restarts a clean game session with zero orphaned components.
  void startNewGame() {
    _clearAllOrbs();
    _currentDropTier = _rollNextSpawnTier();
    _nextDropTier = _rollNextSpawnTier();
    _dropCooldown = 0.0;
    _comboTimer = 0.0;
    _currentCombo = 1;
    _isDangerWarningActive = false;
    _isGameRunning = true;
    _aimX = _arenaRect.center.dx;

    stateNotifier.resetSession(initialTier: _nextDropTier);

    overlays.remove(overlayMainMenu);
    overlays.remove(overlayPause);
    overlays.remove(overlayGameOver);
    overlays.add(overlayHud);
    resumeEngine();
  }

  void pauseGameSession() {
    if (!_isGameRunning) return;
    AudioSynthesizerService.instance.playButtonClick();
    pauseEngine();
    overlays.add(overlayPause);
  }

  void resumeGameSession() {
    AudioSynthesizerService.instance.playButtonClick();
    overlays.remove(overlayPause);
    resumeEngine();
  }

  void returnToMainMenu() {
    AudioSynthesizerService.instance.playButtonClick();
    _isGameRunning = false;
    _clearAllOrbs();
    overlays.remove(overlayHud);
    overlays.remove(overlayPause);
    overlays.remove(overlayGameOver);
    overlays.add(overlayMainMenu);
    resumeEngine();
  }

  /// Rewarded Ad "Second Chance": clears the highest 45% of orbs so the player
  /// can continue their high-score run.
  void reviveWithSecondChance() {
    stateNotifier.markSecondChanceUsed();
    final double cutoffY = _arenaRect.top + _arenaRect.height * 0.52;
    final List<OrbComponent> toRemove =
        _orbs.where((orb) => orb.position.y < cutoffY).toList();

    for (final orb in toRemove) {
      add(
        ParticleFactory.createMergeExplosion(
          position: orb.position,
          color: OrbComponent.colorForTier(orb.tier),
          radius: orb.radius,
        ),
      );
      orb.removeFromParent();
      _orbs.remove(orb);
    }

    for (final orb in _orbs) {
      orb.dangerExposureSeconds = 0.0;
    }

    _isDangerWarningActive = false;
    _isGameRunning = true;
    overlays.remove(overlayGameOver);
    overlays.add(overlayHud);
    resumeEngine();
  }

  void _clearAllOrbs() {
    for (final orb in _orbs) {
      orb.removeFromParent();
    }
    _orbs.clear();
  }

  int _rollNextSpawnTier() {
    // Spawn Tiers 1..4 with weighted probability
    final double roll = _rng.nextDouble();
    if (roll < 0.42) return 1;
    if (roll < 0.75) return 2;
    if (roll < 0.93) return 3;
    return 4;
  }

  @override
  void onPanUpdate(DragUpdateInfo info) {
    if (!_isGameRunning) return;
    final double radius = OrbComponent.radiusForTier(_currentDropTier);
    _aimX = (_aimX + info.delta.global.x).clamp(
      _arenaRect.left + radius + 4.0,
      _arenaRect.right - radius - 4.0,
    );
  }

  @override
  void onPanEnd(DragEndInfo info) {
    if (!_isGameRunning) return;
    _attemptDropOrb();
  }

  @override
  void onTapUp(TapUpEvent event) {
    if (!_isGameRunning) return;
    final double radius = OrbComponent.radiusForTier(_currentDropTier);
    _aimX = event.localPosition.x.clamp(
      _arenaRect.left + radius + 4.0,
      _arenaRect.right - radius - 4.0,
    );
    _attemptDropOrb();
  }

  void _attemptDropOrb() {
    if (_dropCooldown > 0.0 || !_isGameRunning) return;

    final double radius = OrbComponent.radiusForTier(_currentDropTier);
    final double clampedX = _aimX.clamp(
      _arenaRect.left + radius + 4.0,
      _arenaRect.right - radius - 4.0,
    );

    final OrbComponent spawned = OrbComponent(
      tier: _currentDropTier,
      position: Vector2(clampedX, _spawnY),
      initialVelocity: Vector2((_rng.nextDouble() - 0.5) * 14.0, 95.0),
    );

    _orbs.add(spawned);
    add(spawned);
    AudioSynthesizerService.instance.playDrop();

    _currentDropTier = _nextDropTier;
    _nextDropTier = _rollNextSpawnTier();
    _dropCooldown = 0.34;
    stateNotifier.setNextOrbTier(_nextDropTier);
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (!_isGameRunning) return;

    // Cap dt to prevent physics tunneling on background resume
    final double safeDt = math.min(dt, 0.033);

    if (_dropCooldown > 0.0) {
      _dropCooldown = math.max(0.0, _dropCooldown - safeDt);
    }

    if (_comboTimer > 0.0) {
      _comboTimer -= safeDt;
      if (_comboTimer <= 0.0) {
        _currentCombo = 1;
        stateNotifier.resetCombo();
      }
    }

    final double subDt = safeDt / _physicsSubSteps;
    for (int step = 0; step < _physicsSubSteps; step++) {
      _stepPhysics(subDt);
    }

    _checkDangerLineOverflow(safeDt);
  }

  void _stepPhysics(double dt) {
    // 1. Integrate gravity & wall containment
    for (final orb in _orbs) {
      if (orb.isMerging) continue;

      orb.velocity.y += _gravity * dt;
      orb.velocity.scale(0.9985); // Subtle air damping
      orb.position += orb.velocity * dt;

      final double r = orb.radius;
      if (orb.position.x - r < _arenaRect.left) {
        orb.position.x = _arenaRect.left + r;
        orb.velocity.x = -orb.velocity.x * _wallRestitution;
      } else if (orb.position.x + r > _arenaRect.right) {
        orb.position.x = _arenaRect.right - r;
        orb.velocity.x = -orb.velocity.x * _wallRestitution;
      }

      if (orb.position.y + r > _arenaRect.bottom) {
        orb.position.y = _arenaRect.bottom - r;
        if (orb.velocity.y.abs() > 140.0) {
          AudioSynthesizerService.instance.playBounce();
        }
        orb.velocity.y = -orb.velocity.y * _wallRestitution;
        orb.velocity.x *= 0.94; // Floor rolling friction
      }
    }

    // 2. Resolve Orb vs. Bumper deflections
    for (final orb in _orbs) {
      if (orb.isMerging) continue;
      for (final bumper in _bumpers) {
        final Vector2 delta = orb.position - bumper.position;
        final double dist = delta.length;
        final double minDist = orb.radius + bumper.radius;
        if (dist < minDist && dist > 0.0001) {
          final Vector2 normal = delta / dist;
          final double overlap = minDist - dist;
          orb.position += normal * overlap;

          final double vn = orb.velocity.dot(normal);
          if (vn < 0) {
            orb.velocity -= normal * ((1.0 + _bumperRestitution) * vn);
            bumper.triggerHitFlash();
            AudioSynthesizerService.instance.playBounce();
          }
        }
      }
    }

    // 3. Resolve Orb vs. Orb collisions and detect same-tier merges
    final List<(OrbComponent, OrbComponent)> pendingMerges = [];

    for (int i = 0; i < _orbs.length; i++) {
      final OrbComponent a = _orbs[i];
      if (a.isMerging) continue;

      for (int j = i + 1; j < _orbs.length; j++) {
        final OrbComponent b = _orbs[j];
        if (b.isMerging) continue;

        final Vector2 delta = b.position - a.position;
        final double dist = delta.length;
        final double minDist = a.radius + b.radius;

        if (dist < minDist) {
          if (a.tier == b.tier && a.tier < 8) {
            a.isMerging = true;
            b.isMerging = true;
            pendingMerges.add((a, b));
            break;
          }

          // Separate overlapping orbs proportionally to inverse mass
          final Vector2 normal =
              dist > 0.0001 ? (delta / dist) : Vector2(1.0, 0.0);
          final double overlap = minDist - dist;
          final double totalMass = a.mass + b.mass;
          a.position -= normal * (overlap * (b.mass / totalMass));
          b.position += normal * (overlap * (a.mass / totalMass));

          // Impulse momentum exchange
          final Vector2 rv = b.velocity - a.velocity;
          final double velAlongNormal = rv.dot(normal);
          if (velAlongNormal < 0) {
            final double jImpulse = -(1.0 + _orbRestitution) *
                velAlongNormal /
                (1.0 / a.mass + 1.0 / b.mass);
            final Vector2 impulse = normal * jImpulse;
            a.velocity -= impulse / a.mass;
            b.velocity += impulse / b.mass;
          }
        }
      }
    }

    // 4. Execute merges & radial shockwaves
    for (final (OrbComponent a, OrbComponent b) in pendingMerges) {
      _executeMerge(a, b);
    }
  }

  void _executeMerge(OrbComponent a, OrbComponent b) {
    final int nextTier = (a.tier + 1).clamp(1, 8);
    final Vector2 midpoint = (a.position + b.position) * 0.5;
    final Vector2 mergedVelocity = (a.velocity + b.velocity) * 0.45;

    a.removeFromParent();
    b.removeFromParent();
    _orbs.remove(a);
    _orbs.remove(b);

    final OrbComponent merged = OrbComponent(
      tier: nextTier,
      position: midpoint,
      initialVelocity: mergedVelocity,
    );
    _orbs.add(merged);
    add(merged);

    // Spawn high-impact particle burst
    add(
      ParticleFactory.createMergeExplosion(
        position: midpoint,
        color: OrbComponent.colorForTier(nextTier),
        radius: merged.radius,
      ),
    );

    // Apply subtle outward radial shockwave to nearby orbs for dynamic juice
    for (final other in _orbs) {
      if (other == merged || other.isMerging) continue;
      final Vector2 diff = other.position - midpoint;
      final double d = diff.length;
      final double shockRadius = merged.radius * 3.2;
      if (d > 0.001 && d < shockRadius) {
        final double strength = (1.0 - d / shockRadius) * 145.0;
        other.velocity += (diff / d) * strength;
      }
    }

    // Update combo & score
    if (_comboTimer > 0.0) {
      _currentCombo = (_currentCombo + 1).clamp(1, 12);
    } else {
      _currentCombo = 1;
    }
    _comboTimer = 1.85;

    final int basePoints = OrbComponent.valueForTier(nextTier) * 5;
    final int points = basePoints * _currentCombo;
    final int earnedCoins = math.max(1, nextTier - 1);

    AudioSynthesizerService.instance.playMerge(nextTier, combo: _currentCombo);
    stateNotifier.addScoreAndCoins(
      points: points,
      earnedCoins: earnedCoins,
      combo: _currentCombo,
    );
  }

  void _checkDangerLineOverflow(double dt) {
    bool anyNearDanger = false;

    for (final orb in _orbs) {
      if (orb.spawnGraceSeconds > 0.0) continue;

      final double topEdge = orb.position.y - orb.radius;
      if (topEdge < _dangerLineY) {
        anyNearDanger = true;
        orb.dangerExposureSeconds += dt;
        if (orb.dangerExposureSeconds >= 1.65) {
          _triggerGameOver();
          return;
        }
      } else {
        orb.dangerExposureSeconds = math.max(
          0.0,
          orb.dangerExposureSeconds - dt * 2.0,
        );
      }
    }

    _isDangerWarningActive = anyNearDanger;
  }

  void _triggerGameOver() {
    _isGameRunning = false;
    AudioSynthesizerService.instance.playGameOver();
    StorageService.instance.incrementGamesPlayed();
    AdManager.instance.onGameOver();

    overlays.remove(overlayHud);
    overlays.add(overlayGameOver);
  }
}
