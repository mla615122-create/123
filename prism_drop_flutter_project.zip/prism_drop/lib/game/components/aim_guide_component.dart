import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import 'orb_component.dart';

/// Renders the player's horizontal drop cursor, preview orb, and vertical
/// trajectory guide dots before releasing an orb.
class AimGuideComponent extends Component {
  final double Function() getAimX;
  final double Function() getSpawnY;
  final double Function() getFloorY;
  final int Function() getCurrentTier;
  final bool Function() canDrop;

  final Paint _dotPaint = Paint()..style = PaintingStyle.fill;
  final Paint _previewPaint = Paint()..style = PaintingStyle.fill;
  final Paint _previewRimPaint = Paint()
    ..color = Colors.white70
    ..style = PaintingStyle.stroke
    ..strokeWidth = 2.0;

  AimGuideComponent({
    required this.getAimX,
    required this.getSpawnY,
    required this.getFloorY,
    required this.getCurrentTier,
    required this.canDrop,
  });

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    if (!canDrop()) return;

    final double x = getAimX();
    final double y = getSpawnY();
    final double floorY = getFloorY();
    final int tier = getCurrentTier();
    final double radius = OrbComponent.radiusForTier(tier);
    final Color orbColor = OrbComponent.colorForTier(tier);

    // Draw trajectory guide dots
    _dotPaint.color = orbColor.withValues(alpha: 0.32);
    double dotY = y + radius + 14.0;
    while (dotY < floorY - 24.0) {
      canvas.drawCircle(Offset(x, dotY), 2.5, _dotPaint);
      dotY += 20.0;
    }

    // Draw preview orb at drop nozzle
    _previewPaint.color = orbColor.withValues(alpha: 0.85);
    canvas.drawCircle(Offset(x, y), radius, _previewPaint);
    canvas.drawCircle(Offset(x, y), radius - 1.0, _previewRimPaint);
  }
}
