import 'dart:math' as math;
import 'package:flame/collisions.dart';
import 'package:flame/components.dart';
import 'package:flutter/material.dart';
import '../prism_drop_game.dart';

/// Represents a physics-simulated energy orb with a specific tier (1..8).
/// Orbs of identical tiers merge upon contact into `tier + 1`, releasing a
/// radial shockwave impulse to surrounding orbs and awarding combo points.
class OrbComponent extends PositionComponent
    with HasGameReference<PrismDropGame>, CollisionCallbacks {
  final int tier;
  Vector2 velocity;
  double angularVelocity = 0.0;
  bool isMerging = false;
  double dangerExposureSeconds = 0.0;
  double spawnGraceSeconds = 0.65;
  double _spawnScaleProgress = 0.0;

  late final Paint _fillPaint;
  late final Paint _rimPaint;
  late final Paint _highlightPaint;
  late final TextPainter _labelPainter;

  OrbComponent({
    required this.tier,
    required Vector2 position,
    Vector2? initialVelocity,
  })  : velocity = initialVelocity ?? Vector2.zero(),
        super(
          position: position,
          size: Vector2.all(radiusForTier(tier) * 2.0),
          anchor: Anchor.center,
        );

  double get radius => size.x * 0.5;
  double get mass => radius * radius * 0.025;

  static double radiusForTier(int tier) {
    // Smooth geometric progression from 18px (Tier 1) up to 62px (Tier 8)
    return 18.0 + (tier - 1) * 6.3;
  }

  static Color colorForTier(int tier) {
    const List<Color> palette = [
      Color(0xFF00F5D4), // Tier 1: Cyan Pulse
      Color(0xFF00BBF9), // Tier 2: Azure Ion
      Color(0xFF9B5DE5), // Tier 3: Violet Plasma
      Color(0xFFF15BB5), // Tier 4: Magenta Nova
      Color(0xFFFF6B6B), // Tier 5: Crimson Core
      Color(0xFFFFBE0B), // Tier 6: Solar Gold
      Color(0xFF06D6A0), // Tier 7: Emerald Hyper
      Color(0xFFFFFFFF), // Tier 8: Singularity Star
    ];
    return palette[(tier - 1).clamp(0, palette.length - 1)];
  }

  static int valueForTier(int tier) => 1 << tier; // 2, 4, 8, 16, 32, 64, 128, 256

  @override
  Future<void> onLoad() async {
    await super.onLoad();

    final Color baseColor = colorForTier(tier);
    _fillPaint = Paint()
      ..color = baseColor.withValues(alpha: 0.90)
      ..style = PaintingStyle.fill;

    _rimPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.85)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.4;

    _highlightPaint = Paint()
      ..color = Colors.white.withValues(alpha: 0.28)
      ..style = PaintingStyle.fill;

    _labelPainter = TextPainter(
      text: TextSpan(
        text: '${valueForTier(tier)}',
        style: TextStyle(
          color: tier == 8 ? const Color(0xFF0B0F19) : Colors.white,
          fontSize: (radius * 0.68).clamp(11.0, 26.0),
          fontWeight: FontWeight.w900,
          shadows: tier == 8
              ? null
              : const [
                  Shadow(
                    color: Colors.black54,
                    blurRadius: 4,
                    offset: Offset(0, 1),
                  ),
                ],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();

    add(CircleHitbox(radius: radius, anchor: Anchor.center)..position = size / 2);
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (_spawnScaleProgress < 1.0) {
      _spawnScaleProgress = math.min(1.0, _spawnScaleProgress + dt * 7.5);
    }
    if (spawnGraceSeconds > 0) {
      spawnGraceSeconds = math.max(0.0, spawnGraceSeconds - dt);
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final Offset center = Offset(radius, radius);
    final double scale = Curves.easeOutBack.transform(_spawnScaleProgress);

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(scale, scale);

    // Outer orb body
    canvas.drawCircle(Offset.zero, radius, _fillPaint);
    // Specular inner highlight
    canvas.drawCircle(
      Offset(-radius * 0.28, -radius * 0.28),
      radius * 0.34,
      _highlightPaint,
    );
    // Crisp neon rim
    canvas.drawCircle(Offset.zero, radius - 1.2, _rimPaint);

    // Numeric core label
    _labelPainter.paint(
      canvas,
      Offset(-_labelPainter.width * 0.5, -_labelPainter.height * 0.5),
    );

    canvas.restore();
  }
}
