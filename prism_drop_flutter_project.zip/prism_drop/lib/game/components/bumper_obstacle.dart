import 'dart:math' as math;
import 'package:flame/components.dart';
import 'package:flutter/material.dart';

/// Dynamic pinball-style energy bumper inside the arena that deflects falling
/// orbs, adding skill-based bank-shot physics to the puzzle arena.
class BumperObstacle extends PositionComponent {
  final double radius;
  double _pulseTimer = 0.0;
  double _hitFlash = 0.0;

  late final Paint _corePaint;
  late final Paint _ringPaint;

  BumperObstacle({
    required Vector2 position,
    this.radius = 16.0,
  }) : super(
          position: position,
          size: Vector2.all(radius * 2.0),
          anchor: Anchor.center,
        );

  void triggerHitFlash() {
    _hitFlash = 1.0;
  }

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    _corePaint = Paint()
      ..color = const Color(0xFF1E293B)
      ..style = PaintingStyle.fill;

    _ringPaint = Paint()
      ..color = const Color(0xFF38BDF8)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.0;
  }

  @override
  void update(double dt) {
    super.update(dt);
    _pulseTimer += dt * 3.2;
    if (_hitFlash > 0) {
      _hitFlash = math.max(0.0, _hitFlash - dt * 4.5);
    }
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final Offset center = Offset(radius, radius);
    final double pulse = 1.0 + math.sin(_pulseTimer) * 0.06 + _hitFlash * 0.22;

    canvas.save();
    canvas.translate(center.dx, center.dy);
    canvas.scale(pulse, pulse);

    canvas.drawCircle(Offset.zero, radius, _corePaint);
    _ringPaint.color = Color.lerp(
      const Color(0xFF38BDF8),
      const Color(0xFFF43F5E),
      _hitFlash,
    )!;
    canvas.drawCircle(Offset.zero, radius - 1.5, _ringPaint);
    canvas.restore();
  }
}
