import 'dart:math' as math;
import 'package:flame/components.dart';
import 'package:flutter/material.dart';

/// Renders the containment chamber walls, floor, and the animated laser
/// overflow threshold line near the top of the chamber.
class ArenaBoundary extends Component {
  final Rect Function() getArenaRect;
  final double Function() getDangerLineY;
  final bool Function() isDangerActive;

  double _laserPhase = 0.0;

  final Paint _bgPaint = Paint()
    ..color = const Color(0xFF0F172A).withValues(alpha: 0.86)
    ..style = PaintingStyle.fill;

  final Paint _borderPaint = Paint()
    ..color = const Color(0xFF334155)
    ..style = PaintingStyle.stroke
    ..strokeWidth = 3.0;

  final Paint _dangerPaint = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 2.0;

  ArenaBoundary({
    required this.getArenaRect,
    required this.getDangerLineY,
    required this.isDangerActive,
  });

  @override
  void update(double dt) {
    super.update(dt);
    _laserPhase += dt * 6.0;
  }

  @override
  void render(Canvas canvas) {
    super.render(canvas);
    final Rect rect = getArenaRect();
    final RRect rrect = RRect.fromRectAndRadius(rect, const Radius.circular(18));

    canvas.drawRRect(rrect, _bgPaint);
    canvas.drawRRect(rrect, _borderPaint);

    // Draw dashed danger threshold line
    final double dangerY = getDangerLineY();
    final bool danger = isDangerActive();
    final double alpha = danger
        ? (0.55 + 0.45 * math.sin(_laserPhase).abs())
        : 0.35;

    _dangerPaint.color = (danger
            ? const Color(0xFFEF4444)
            : const Color(0xFFF59E0B))
        .withValues(alpha: alpha);

    const double dashWidth = 10.0;
    const double dashSpace = 7.0;
    double startX = rect.left + 12.0;
    final double endX = rect.right - 12.0;
    while (startX < endX) {
      canvas.drawLine(
        Offset(startX, dangerY),
        Offset(math.min(startX + dashWidth, endX), dangerY),
        _dangerPaint,
      );
      startX += dashWidth + dashSpace;
    }
  }
}
