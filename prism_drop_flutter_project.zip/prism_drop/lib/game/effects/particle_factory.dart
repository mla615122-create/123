import 'dart:math' as math;
import 'package:flame/components.dart';
import 'package:flame/particles.dart';
import 'package:flutter/material.dart';

/// Factory for high-impact particle bursts and shockwave rings that give
/// merges and combos tactile visual punch ("game juice") with zero memory leaks.
class ParticleFactory {
  ParticleFactory._();
  static final math.Random _rng = math.Random();

  static ParticleSystemComponent createMergeExplosion({
    required Vector2 position,
    required Color color,
    required double radius,
  }) {
    return ParticleSystemComponent(
      position: position.clone(),
      particle: Particle.generate(
        count: 24,
        lifespan: 0.48,
        generator: (int i) {
          final double angle = (i / 24.0) * 2.0 * math.pi +
              (_rng.nextDouble() - 0.5) * 0.25;
          final double speed = 90.0 + _rng.nextDouble() * 190.0;
          final Vector2 velocity = Vector2(
            math.cos(angle) * speed,
            math.sin(angle) * speed,
          );
          final double particleRadius = 2.5 + _rng.nextDouble() * 4.0;

          return AcceleratedParticle(
            speed: velocity,
            acceleration: Vector2(0, 260.0),
            child: ComputedParticle(
              renderer: (Canvas canvas, Particle particle) {
                final double opacity = (1.0 - particle.progress).clamp(0.0, 1.0);
                final Paint paint = Paint()
                  ..color = Color.lerp(color, Colors.white, 0.35)!
                      .withValues(alpha: opacity)
                  ..style = PaintingStyle.fill;
                canvas.drawCircle(
                  Offset.zero,
                  particleRadius * (1.0 - particle.progress * 0.5),
                  paint,
                );
              },
            ),
          );
        },
      ),
    );
  }
}
