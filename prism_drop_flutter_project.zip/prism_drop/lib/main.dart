import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'game/prism_drop_game.dart';
import 'services/ad_manager.dart';
import 'services/audio_synthesizer_service.dart';
import 'services/iap_service.dart';
import 'services/storage_service.dart';
import 'state/game_state_notifier.dart';
import 'ui/banner_ad_container.dart';
import 'ui/game_over_overlay.dart';
import 'ui/hud_overlay.dart';
import 'ui/main_menu_overlay.dart';
import 'ui/pause_overlay.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Lock orientation to portrait and enable immersive edge-to-edge mode
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

  // Initialize persistence, procedural audio synthesizer, IAP, and UMP Consent + AdMob
  await StorageService.instance.init();
  await AudioSynthesizerService.instance.init();
  await IapService.instance.init();
  await AdManager.instance.initializeWithConsent();

  runApp(
    const ProviderScope(
      child: PrismDropApp(),
    ),
  );
}

class PrismDropApp extends ConsumerStatefulWidget {
  const PrismDropApp({super.key});

  @override
  ConsumerState<PrismDropApp> createState() => _PrismDropAppState();
}

class _PrismDropAppState extends ConsumerState<PrismDropApp> {
  PrismDropGame? _game;

  @override
  Widget build(BuildContext context) {
    final notifier = ref.read(gameStateProvider.notifier);
    _game ??= PrismDropGame(stateNotifier: notifier);

    return MaterialApp(
      title: 'Prism Drop',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: const Color(0xFF070B14),
      ),
      home: Scaffold(
        body: Column(
          children: [
            Expanded(
              child: GameWidget<PrismDropGame>(
                game: _game!,
                initialActiveOverlays: const [PrismDropGame.overlayMainMenu],
                overlayBuilderMap: {
                  PrismDropGame.overlayMainMenu: (context, game) =>
                      MainMenuOverlay(game: game),
                  PrismDropGame.overlayHud: (context, game) =>
                      HudOverlay(game: game),
                  PrismDropGame.overlayPause: (context, game) =>
                      PauseOverlay(game: game),
                  PrismDropGame.overlayGameOver: (context, game) =>
                      GameOverOverlay(game: game),
                },
              ),
            ),
            const BannerAdContainer(),
          ],
        ),
      ),
    );
  }
}
