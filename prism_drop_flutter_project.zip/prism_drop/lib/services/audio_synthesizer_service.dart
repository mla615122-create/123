import 'dart:math' as math;
import 'dart:typed_data';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';
import 'storage_service.dart';

/// Procedural PCM WAV audio synthesizer and haptic feedback controller.
/// Generates zero-allocation in-memory 16-bit mono RIFF WAV byte buffers at
/// startup so the game plays crisp retro-futuristic sound effects out of the
/// box without requiring external binary audio assets.
class AudioSynthesizerService {
  AudioSynthesizerService._();
  static final AudioSynthesizerService instance = AudioSynthesizerService._();

  final List<AudioPlayer> _pool = [];
  int _poolIndex = 0;
  static const int _poolSize = 4;

  late Uint8List _dropWav;
  late Uint8List _bounceWav;
  late List<Uint8List> _mergeChordWavs;
  late Uint8List _gameOverWav;
  late Uint8List _buttonClickWav;

  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;

    for (int i = 0; i < _poolSize; i++) {
      final player = AudioPlayer();
      await player.setReleaseMode(ReleaseMode.stop);
      _pool.add(player);
    }

    // Pre-synthesize WAV buffers once at startup (22050 Hz, 16-bit mono)
    _dropWav = _synthesizeSweep(
      startFreq: 520.0,
      endFreq: 240.0,
      durationSeconds: 0.09,
      volume: 0.45,
    );

    _bounceWav = _synthesizeSweep(
      startFreq: 180.0,
      endFreq: 120.0,
      durationSeconds: 0.05,
      volume: 0.22,
    );

    // Rising pentatonic harmonic chimes for tier merges (Tiers 1..8)
    const List<double> baseFreqs = [
      261.63, // C4
      293.66, // D4
      329.63, // E4
      392.00, // G4
      440.00, // A4
      523.25, // C5
      659.25, // E5
      783.99, // G5
    ];
    _mergeChordWavs = List.generate(baseFreqs.length, (index) {
      final root = baseFreqs[index];
      return _synthesizeChord(
        frequencies: [root, root * 1.25, root * 1.5],
        durationSeconds: 0.22,
        volume: 0.55,
      );
    });

    _gameOverWav = _synthesizeSweep(
      startFreq: 340.0,
      endFreq: 95.0,
      durationSeconds: 0.45,
      volume: 0.50,
    );

    _buttonClickWav = _synthesizeSweep(
      startFreq: 680.0,
      endFreq: 880.0,
      durationSeconds: 0.045,
      volume: 0.35,
    );

    _initialized = true;
  }

  void playDrop() {
    _triggerHaptic(HapticLevel.light);
    _playBuffer(_dropWav);
  }

  void playBounce() {
    _playBuffer(_bounceWav);
  }

  void playMerge(int tier, {int combo = 1}) {
    if (combo >= 3 || tier >= 5) {
      _triggerHaptic(HapticLevel.heavy);
    } else {
      _triggerHaptic(HapticLevel.medium);
    }
    final clampedIndex = (tier - 1).clamp(0, _mergeChordWavs.length - 1);
    _playBuffer(_mergeChordWavs[clampedIndex]);
  }

  void playGameOver() {
    _triggerHaptic(HapticLevel.vibrate);
    _playBuffer(_gameOverWav);
  }

  void playButtonClick() {
    _triggerHaptic(HapticLevel.selection);
    _playBuffer(_buttonClickWav);
  }

  void _playBuffer(Uint8List wavBytes) {
    if (!_initialized || !StorageService.instance.soundEnabled) return;
    final player = _pool[_poolIndex];
    _poolIndex = (_poolIndex + 1) % _pool.length;
    player.play(BytesSource(wavBytes));
  }

  void _triggerHaptic(HapticLevel level) {
    if (!StorageService.instance.hapticsEnabled) return;
    switch (level) {
      case HapticLevel.selection:
        HapticFeedback.selectionClick();
      case HapticLevel.light:
        HapticFeedback.lightImpact();
      case HapticLevel.medium:
        HapticFeedback.mediumImpact();
      case HapticLevel.heavy:
        HapticFeedback.heavyImpact();
      case HapticLevel.vibrate:
        HapticFeedback.vibrate();
    }
  }

  /// Generates a 16-bit PCM mono WAV buffer with linear frequency sweep and
  /// exponential decay envelope.
  Uint8List _synthesizeSweep({
    required double startFreq,
    required double endFreq,
    required double durationSeconds,
    required double volume,
    int sampleRate = 22050,
  }) {
    final int numSamples = (sampleRate * durationSeconds).round();
    final Float64List samples = Float64List(numSamples);
    double phase = 0.0;

    for (int i = 0; i < numSamples; i++) {
      final double progress = i / numSamples;
      final double freq = startFreq + (endFreq - startFreq) * progress;
      final double envelope = math.pow(1.0 - progress, 1.8).toDouble();
      samples[i] = math.sin(phase) * volume * envelope;
      phase += (2.0 * math.pi * freq) / sampleRate;
    }
    return _encodePcm16Wav(samples, sampleRate);
  }

  /// Generates a harmonic multi-tone chime WAV buffer.
  Uint8List _synthesizeChord({
    required List<double> frequencies,
    required double durationSeconds,
    required double volume,
    int sampleRate = 22050,
  }) {
    final int numSamples = (sampleRate * durationSeconds).round();
    final Float64List samples = Float64List(numSamples);

    for (int i = 0; i < numSamples; i++) {
      final double t = i / sampleRate;
      final double progress = i / numSamples;
      final double attack = progress < 0.05 ? (progress / 0.05) : 1.0;
      final double decay = math.pow(1.0 - progress, 2.0).toDouble();
      double sum = 0.0;
      for (final freq in frequencies) {
        sum += math.sin(2.0 * math.pi * freq * t);
      }
      samples[i] = (sum / frequencies.length) * volume * attack * decay;
    }
    return _encodePcm16Wav(samples, sampleRate);
  }

  /// Packs normalized [-1.0, 1.0] float samples into a valid RIFF WAVE header + PCM16 payload.
  Uint8List _encodePcm16Wav(Float64List samples, int sampleRate) {
    final int dataSize = samples.length * 2;
    final int fileSize = 44 + dataSize;
    final ByteData buffer = ByteData(fileSize);

    // RIFF chunk descriptor
    _writeAscii(buffer, 0, 'RIFF');
    buffer.setUint32(4, fileSize - 8, Endian.little);
    _writeAscii(buffer, 8, 'WAVE');

    // fmt sub-chunk
    _writeAscii(buffer, 12, 'fmt ');
    buffer.setUint32(16, 16, Endian.little); // PCM chunk size
    buffer.setUint16(20, 1, Endian.little); // AudioFormat = 1 (PCM)
    buffer.setUint16(22, 1, Endian.little); // NumChannels = 1 (Mono)
    buffer.setUint32(24, sampleRate, Endian.little); // SampleRate
    buffer.setUint32(28, sampleRate * 2, Endian.little); // ByteRate
    buffer.setUint16(32, 2, Endian.little); // BlockAlign
    buffer.setUint16(34, 16, Endian.little); // BitsPerSample = 16

    // data sub-chunk
    _writeAscii(buffer, 36, 'data');
    buffer.setUint32(40, dataSize, Endian.little);

    int offset = 44;
    for (int i = 0; i < samples.length; i++) {
      final int pcm = (samples[i].clamp(-1.0, 1.0) * 32767.0).round();
      buffer.setInt16(offset, pcm, Endian.little);
      offset += 2;
    }

    return buffer.buffer.asUint8List();
  }

  void _writeAscii(ByteData data, int offset, String value) {
    for (int i = 0; i < value.length; i++) {
      data.setUint8(offset + i, value.codeUnitAt(i));
    }
  }

  Future<void> dispose() async {
    for (final player in _pool) {
      await player.dispose();
    }
    _pool.clear();
    _initialized = false;
  }
}

enum HapticLevel { selection, light, medium, heavy, vibrate }
