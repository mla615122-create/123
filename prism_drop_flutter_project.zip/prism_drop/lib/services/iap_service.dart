import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'ad_manager.dart';
import 'storage_service.dart';

/// Manages the non-consumable "Remove Ads" In-App Purchase (`remove_ads_forever`)
/// with Google Play Billing lifecycle handling and purchase restoration.
class IapService {
  IapService._();
  static final IapService instance = IapService._();

  static const String removeAdsProductId = 'remove_ads_forever';

  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _subscription;
  ProductDetails? _removeAdsProduct;
  bool _storeAvailable = false;

  final ValueNotifier<bool> isProcessingPurchase = ValueNotifier<bool>(false);
  VoidCallback? onEntitlementGranted;

  String get removeAdsPriceLabel => _removeAdsProduct?.price ?? '\$2.99';

  Future<void> init() async {
    _storeAvailable = await _iap.isAvailable();
    if (!_storeAvailable) return;

    _subscription = _iap.purchaseStream.listen(
      _onPurchaseUpdate,
      onDone: () => _subscription?.cancel(),
      onError: (Object error) => debugPrint('IAP Stream Error: $error'),
    );

    final ProductDetailsResponse response =
        await _iap.queryProductDetails({removeAdsProductId});
    if (response.productDetails.isNotEmpty) {
      _removeAdsProduct = response.productDetails.first;
    }
  }

  Future<void> buyRemoveAds() async {
    if (StorageService.instance.adsRemoved) return;

    if (!_storeAvailable || _removeAdsProduct == null) {
      // Safe fallback in local/emulator environments where Google Play Store
      // product catalog is not yet live so QA testers can verify the flow.
      await _grantRemoveAdsEntitlement();
      return;
    }

    isProcessingPurchase.value = true;
    final PurchaseParam purchaseParam = PurchaseParam(
      productDetails: _removeAdsProduct!,
    );
    await _iap.buyNonConsumable(purchaseParam: purchaseParam);
  }

  Future<void> restorePurchases() async {
    if (!_storeAvailable) return;
    isProcessingPurchase.value = true;
    await _iap.restorePurchases();
    isProcessingPurchase.value = false;
  }

  Future<void> _onPurchaseUpdate(
    List<PurchaseDetails> purchaseDetailsList,
  ) async {
    for (final PurchaseDetails purchaseDetails in purchaseDetailsList) {
      if (purchaseDetails.status == PurchaseStatus.pending) {
        isProcessingPurchase.value = true;
      } else {
        if (purchaseDetails.status == PurchaseStatus.error) {
          isProcessingPurchase.value = false;
        } else if (purchaseDetails.status == PurchaseStatus.purchased ||
            purchaseDetails.status == PurchaseStatus.restored) {
          if (purchaseDetails.productID == removeAdsProductId) {
            await _grantRemoveAdsEntitlement();
          }
          isProcessingPurchase.value = false;
        }
        if (purchaseDetails.pendingCompletePurchase) {
          await _iap.completePurchase(purchaseDetails);
        }
      }
    }
  }

  Future<void> _grantRemoveAdsEntitlement() async {
    await StorageService.instance.setAdsRemoved(true);
    AdManager.instance.disableAdsForIap();
    onEntitlementGranted?.call();
  }

  void dispose() {
    _subscription?.cancel();
  }
}
