import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'storage_service.dart';

/// Google Play 2026 compliant AdMob & UMP (User Messaging Platform) manager.
/// Handles:
/// 1. GDPR / EEA & UK IAB TCF v2.2 consent gathering via Google UMP SDK.
/// 2. COPPA child-directed / under-age-of-consent safe ad request tagging.
/// 3. Bottom adaptive Banner Ad, Interstitial every 4 game-overs, and
///    Rewarded video ads for extra life ("Second Chance") or double coins.
class AdManager {
  AdManager._();
  static final AdManager instance = AdManager._();

  final ValueNotifier<BannerAd?> bannerAdNotifier = ValueNotifier<BannerAd?>(null);
  final ValueNotifier<bool> isRewardedAdReady = ValueNotifier<bool>(false);

  InterstitialAd? _interstitialAd;
  RewardedAd? _rewardedAd;
  bool _isInitialized = false;
  bool _canRequestAds = false;
  int _gameOverCounter = 0;

  static const int interstitialFrequency = 4;

  // Official Google Test Ad Unit IDs (safe for development and automated verification)
  String get _bannerAdUnitId {
    if ( !kIsWeb && Platform.isIOS) {
      return 'ca-app-pub-3940256099942544/2934735716';
    }
    return 'ca-app-pub-3940256099942544/6300978111';
  }

  String get _interstitialAdUnitId {
    if (!kIsWeb && Platform.isIOS) {
      return 'ca-app-pub-3940256099942544/4411468910';
    }
    return 'ca-app-pub-3940256099942544/1033173712';
  }

  String get _rewardedAdUnitId {
    if (!kIsWeb && Platform.isIOS) {
      return 'ca-app-pub-3940256099942544/1712485313';
    }
    return 'ca-app-pub-3940256099942544/5224354917';
  }

  /// Initializes UMP Consent flow first, then boots MobileAds SDK only when allowed.
  Future<void> initializeWithConsent() async {
    if (kIsWeb) return;

    final bool isUnderAge = StorageService.instance.isUnderAgeCoppa;

    // Configure COPPA & Max Ad Content Rating (G for family/all-ages safety if under-age)
    await MobileAds.instance.updateRequestConfiguration(
      RequestConfiguration(
        tagForUnderAgeOfConsent: isUnderAge
            ? TagForUnderAgeOfConsent.yes
            : TagForUnderAgeOfConsent.no,
        tagForChildDirectedTreatment: isUnderAge
            ? TagForChildDirectedTreatment.yes
            : TagForChildDirectedTreatment.no,
        maxAdContentRating: isUnderAge
            ? MaxAdContentRating.g
            : MaxAdContentRating.pg,
      ),
    );

    final Completer<void> consentCompleter = Completer<void>();
    final ConsentRequestParameters params = ConsentRequestParameters(
      tagForUnderAgeOfConsent: isUnderAge,
    );

    ConsentInformation.instance.requestConsentInfoUpdate(
      params,
      () async {
        await ConsentForm.loadAndShowConsentFormIfRequired((FormError? error) {
          if (error != null) {
            debugPrint('UMP Consent Form message: ${error.message}');
          }
          if (!consentCompleter.isCompleted) {
            consentCompleter.complete();
          }
        });
      },
      (FormError error) {
        debugPrint('UMP Consent Info Update fallback: ${error.message}');
        if (!consentCompleter.isCompleted) {
          consentCompleter.complete();
        }
      },
    );

    await consentCompleter.future;
    _canRequestAds = await ConsentInformation.instance.canRequestAds();

    if (_canRequestAds && !_isInitialized) {
      await MobileAds.instance.initialize();
      _isInitialized = true;
      if (!StorageService.instance.adsRemoved) {
        loadBannerAd();
        _loadInterstitialAd();
      }
      _loadRewardedAd();
    }
  }

  AdRequest _buildAdRequest() {
    // Serve non-personalized ads automatically when under-age mode is active
    final bool nonPersonalized = StorageService.instance.isUnderAgeCoppa;
    return AdRequest(nonPersonalizedAds: nonPersonalized);
  }

  void loadBannerAd() {
    if (!_isInitialized ||
        !_canRequestAds ||
        StorageService.instance.adsRemoved ||
        bannerAdNotifier.value != null) {
      return;
    }

    final BannerAd banner = BannerAd(
      adUnitId: _bannerAdUnitId,
      size: AdSize.banner,
      request: _buildAdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (Ad ad) {
          if (StorageService.instance.adsRemoved) {
            ad.dispose();
            return;
          }
          bannerAdNotifier.value = ad as BannerAd;
        },
        onAdFailedToLoad: (Ad ad, LoadAdError error) {
          ad.dispose();
          bannerAdNotifier.value = null;
          debugPrint('Banner failed to load: ${error.message}');
        },
      ),
    );
    banner.load();
  }

  void _loadInterstitialAd() {
    if (!_isInitialized ||
        !_canRequestAds ||
        StorageService.instance.adsRemoved ||
        _interstitialAd != null) {
      return;
    }

    InterstitialAd.load(
      adUnitId: _interstitialAdUnitId,
      request: _buildAdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (InterstitialAd ad) {
          _interstitialAd = ad;
        },
        onAdFailedToLoad: (LoadAdError error) {
          _interstitialAd = null;
          debugPrint('Interstitial failed to load: ${error.message}');
        },
      ),
    );
  }

  void _loadRewardedAd() {
    if (!_isInitialized || !_canRequestAds || _rewardedAd != null) {
      return;
    }

    RewardedAd.load(
      adUnitId: _rewardedAdUnitId,
      request: _buildAdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (RewardedAd ad) {
          _rewardedAd = ad;
          isRewardedAdReady.value = true;
        },
        onAdFailedToLoad: (LoadAdError error) {
          _rewardedAd = null;
          isRewardedAdReady.value = false;
          debugPrint('Rewarded ad failed to load: ${error.message}');
        },
      ),
    );
  }

  /// Displays an interstitial ad every 4th Game Over unless "Remove Ads" is active.
  void onGameOver() {
    if (StorageService.instance.adsRemoved) return;

    _gameOverCounter++;
    if (_gameOverCounter >= interstitialFrequency) {
      _gameOverCounter = 0;
      if (_interstitialAd != null) {
        _interstitialAd!.fullScreenContentCallback = FullScreenContentCallback(
          onAdDismissedFullScreenContent: (InterstitialAd ad) {
            ad.dispose();
            _interstitialAd = null;
            _loadInterstitialAd();
          },
          onAdFailedToShowFullScreenContent: (InterstitialAd ad, AdError err) {
            ad.dispose();
            _interstitialAd = null;
            _loadInterstitialAd();
          },
        );
        _interstitialAd!.show();
      } else {
        _loadInterstitialAd();
      }
    }
  }

  /// Shows a Rewarded Video Ad for an extra life ("Second Chance") or 2x coin bonus.
  Future<bool> showRewardedAd({required VoidCallback onRewardEarned}) async {
    final RewardedAd? ad = _rewardedAd;
    if (ad == null) {
      _loadRewardedAd();
      return false;
    }

    final Completer<bool> completer = Completer<bool>();
    bool earned = false;

    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (RewardedAd ad) {
        ad.dispose();
        _rewardedAd = null;
        isRewardedAdReady.value = false;
        _loadRewardedAd();
        if (!completer.isCompleted) completer.complete(earned);
      },
      onAdFailedToShowFullScreenContent: (RewardedAd ad, AdError error) {
        ad.dispose();
        _rewardedAd = null;
        isRewardedAdReady.value = false;
        _loadRewardedAd();
        if (!completer.isCompleted) completer.complete(false);
      },
    );

    await ad.show(
      onUserEarnedReward: (AdWithoutView adView, RewardItem reward) {
        earned = true;
        onRewardEarned();
      },
    );

    return completer.future;
  }

  /// Permanently disables banner and interstitial ads after IAP unlock.
  void disableAdsForIap() {
    bannerAdNotifier.value?.dispose();
    bannerAdNotifier.value = null;
    _interstitialAd?.dispose();
    _interstitialAd = null;
  }
}
