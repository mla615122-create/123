import 'package:shared_preferences/shared_preferences.dart';

/// Thread-safe singleton wrapper around [SharedPreferences] for persisting
/// high scores, coins, audio/haptic preferences, and IAP entitlements.
class StorageService {
  StorageService._();
  static final StorageService instance = StorageService._();

  static const String _keyHighScore = 'prism_drop_high_score';
  static const String _keyCoins = 'prism_drop_coins';
  static const String _keySoundEnabled = 'prism_drop_sound_enabled';
  static const String _keyHapticsEnabled = 'prism_drop_haptics_enabled';
  static const String _keyAdsRemoved = 'prism_drop_ads_removed';
  static const String _keyGamesPlayed = 'prism_drop_games_played';
  static const String _keyUnderAgeCoppa = 'prism_drop_under_age_coppa';

  late SharedPreferences _prefs;
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    _prefs = await SharedPreferences.getInstance();
    _initialized = true;
  }

  int get highScore => _prefs.getInt(_keyHighScore) ?? 0;
  Future<void> setHighScore(int value) async {
    if (value > highScore) {
      await _prefs.setInt(_keyHighScore, value);
    }
  }

  int get coins => _prefs.getInt(_keyCoins) ?? 0;
  Future<void> setCoins(int value) async {
    await _prefs.setInt(_keyCoins, value < 0 ? 0 : value);
  }

  Future<void> addCoins(int delta) async {
    await setCoins(coins + delta);
  }

  bool get soundEnabled => _prefs.getBool(_keySoundEnabled) ?? true;
  Future<void> setSoundEnabled(bool enabled) async {
    await _prefs.setBool(_keySoundEnabled, enabled);
  }

  bool get hapticsEnabled => _prefs.getBool(_keyHapticsEnabled) ?? true;
  Future<void> setHapticsEnabled(bool enabled) async {
    await _prefs.setBool(_keyHapticsEnabled, enabled);
  }

  bool get adsRemoved => _prefs.getBool(_keyAdsRemoved) ?? false;
  Future<void> setAdsRemoved(bool removed) async {
    await _prefs.setBool(_keyAdsRemoved, removed);
  }

  int get gamesPlayed => _prefs.getInt(_keyGamesPlayed) ?? 0;
  Future<int> incrementGamesPlayed() async {
    final next = gamesPlayed + 1;
    await _prefs.setInt(_keyGamesPlayed, next);
    return next;
  }

  bool get isUnderAgeCoppa => _prefs.getBool(_keyUnderAgeCoppa) ?? false;
  Future<void> setUnderAgeCoppa(bool value) async {
    await _prefs.setBool(_keyUnderAgeCoppa, value);
  }
}
