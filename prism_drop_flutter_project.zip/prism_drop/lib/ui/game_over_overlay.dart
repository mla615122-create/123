import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../game/prism_drop_game.dart';
import '../services/ad_manager.dart';
import '../services/audio_synthesizer_service.dart';
import '../state/game_state_notifier.dart';

/// Displays the Game Over modal with an animated score count-up, pulsing
/// "NEW HIGH SCORE!" badge, and Rewarded Ad buttons for Second Chance revive
/// or 2x session coins.
class GameOverOverlay extends ConsumerStatefulWidget {
  final PrismDropGame game;

  const GameOverOverlay({super.key, required this.game});

  @override
  ConsumerState<GameOverOverlay> createState() => _GameOverOverlayState();
}

class _GameOverOverlayState extends ConsumerState<GameOverOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulseController;
  bool _doubledCoins = false;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final session = ref.watch(gameStateProvider);
    final notifier = ref.read(gameStateProvider.notifier);

    return Container(
      color: Colors.black87,
      alignment: Alignment.center,
      padding: const EdgeInsets.all(24),
      child: Container(
        padding: const EdgeInsets.all(26),
        decoration: BoxDecoration(
          color: const Color(0xFF0F172A),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: const Color(0xFFF15BB5), width: 2),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'CONTAINMENT BREACH',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w900,
                color: Colors.white,
                letterSpacing: 1.4,
              ),
            ),
            const SizedBox(height: 12),
            if (session.isNewHighScore)
              ScaleTransition(
                scale: Tween<double>(begin: 0.94, end: 1.08)
                    .animate(_pulseController),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFFFFBE0B),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Text(
                    'NEW HIGH SCORE!',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w900,
                      color: Color(0xFF070B14),
                    ),
                  ),
                ),
              ),
            const SizedBox(height: 16),

            // Animated Score Counter
            TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0, end: session.score.toDouble()),
              duration: const Duration(milliseconds: 950),
              curve: Curves.easeOutCubic,
              builder: (context, double value, _) {
                return Text(
                  '${value.round()}',
                  style: const TextStyle(
                    fontSize: 48,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF00F5D4),
                  ),
                );
              },
            ),
            Text(
              'BEST SCORE: ${session.highScore}',
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: Colors.white70,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              '+${session.sessionCoins} Coins Earned',
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: Color(0xFFFFBE0B),
              ),
            ),
            const SizedBox(height: 22),

            // Rewarded Video Option 1: Second Chance (Clear top orbs & continue)
            if (!session.secondChanceUsed)
              Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton.icon(
                    onPressed: () async {
                      AudioSynthesizerService.instance.playButtonClick();
                      final bool rewarded =
                          await AdManager.instance.showRewardedAd(
                        onRewardEarned: () {
                          widget.game.reviveWithSecondChance();
                        },
                      );
                      if (!rewarded && context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text('Rewarded video still loading...'),
                            duration: Duration(seconds: 2),
                          ),
                        );
                      }
                    },
                    icon: const Icon(Icons.bolt_rounded),
                    label: const Text(
                      'SECOND CHANCE (WATCH AD)',
                      style: TextStyle(fontWeight: FontWeight.w900),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFF15BB5),
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ),

            // Rewarded Video Option 2: 2x Session Coins
            if (!_doubledCoins && session.sessionCoins > 0)
              Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: OutlinedButton.icon(
                    onPressed: () async {
                      AudioSynthesizerService.instance.playButtonClick();
                      await AdManager.instance.showRewardedAd(
                        onRewardEarned: () {
                          notifier.doubleSessionCoins();
                          if (mounted) {
                            setState(() => _doubledCoins = true);
                          }
                        },
                      );
                    },
                    icon: const Icon(
                      Icons.monetization_on_rounded,
                      color: Color(0xFFFFBE0B),
                    ),
                    label: const Text(
                      '2X COINS (WATCH AD)',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFFFFBE0B)),
                    ),
                  ),
                ),
              ),

            // Play Again CTA
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton.icon(
                onPressed: () {
                  AudioSynthesizerService.instance.playButtonClick();
                  widget.game.startNewGame();
                },
                icon: const Icon(Icons.replay_rounded),
                label: const Text(
                  'PLAY AGAIN',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00F5D4),
                  foregroundColor: const Color(0xFF070B14),
                ),
              ),
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: widget.game.returnToMainMenu,
              child: const Text(
                'MAIN MENU',
                style: TextStyle(color: Colors.white60),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
