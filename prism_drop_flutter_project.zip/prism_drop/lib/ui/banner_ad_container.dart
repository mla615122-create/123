import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import '../services/ad_manager.dart';

/// Displays the adaptive bottom AdMob Banner Ad while respecting device
/// bottom safe-area insets and collapsing automatically if "Remove Ads" is owned.
class BannerAdContainer extends StatelessWidget {
  const BannerAdContainer({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<BannerAd?>(
      valueListenable: AdManager.instance.bannerAdNotifier,
      builder: (context, BannerAd? bannerAd, _) {
        if (bannerAd == null) {
          return const SizedBox.shrink();
        }
        return SafeArea(
          top: false,
          child: Container(
            alignment: Alignment.center,
            width: bannerAd.size.width.toDouble(),
            height: bannerAd.size.height.toDouble(),
            color: const Color(0xFF070B14),
            child: AdWidget(ad: bannerAd),
          ),
        );
      },
    );
  }
}
