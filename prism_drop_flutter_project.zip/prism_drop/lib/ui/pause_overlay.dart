import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../game/prism_drop_game.dart';
import '../state/game_state_notifier.dart';

class PauseOverlay extends ConsumerWidget {
  final PrismDropGame game;

  const PauseOverlay({super.key, required this.game});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final session = ref.watch(gameStateProvider);
    final notifier = ref.read(gameStateProvider.notifier);

    return Container(
      color: Colors.black54,
      alignment: Alignment.center,
      padding: const EdgeInsets.all(28),
      child: Container(
        padding: const EdgeInsets.all(26),
        decoration: BoxDecoration(
          color: const Color(0xFF0F172A),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: const Color(0xFF38BDF8), width: 1.5),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'GAME PAUSED',
              style: TextStyle(
                fontSize: 26,
                fontWeight: FontWeight.w900,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 20),
            SwitchListTile(
              value: session.soundEnabled,
              onChanged: (_) => notifier.toggleSound(),
              title: const Text(
                'Synthesized Audio FX',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
              ),
              activeColor: const Color(0xFF00F5D4),
            ),
            SwitchListTile(
              value: session.hapticsEnabled,
              onChanged: (_) => notifier.toggleHaptics(),
              title: const Text(
                'Haptic Vibration',
                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
              ),
              activeColor: const Color(0xFF00F5D4),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton.icon(
                onPressed: game.resumeGameSession,
                icon: const Icon(Icons.play_arrow_rounded),
                label: const Text(
                  'RESUME',
                  style: TextStyle(fontWeight: FontWeight.w900),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00F5D4),
                  foregroundColor: const Color(0xFF070B14),
                ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              height: 48,
              child: OutlinedButton.icon(
                onPressed: game.startNewGame,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('RESTART'),
                style: OutlinedButton.styleFrom(foregroundColor: Colors.white),
              ),
            ),
            const SizedBox(height: 8),
            TextButton(
              onPressed: game.returnToMainMenu,
              child: const Text(
                'MAIN MENU',
                style: TextStyle(color: Colors.white60),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
