import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../game/prism_drop_game.dart';
import '../services/audio_synthesizer_service.dart';
import '../services/iap_service.dart';
import '../state/game_state_notifier.dart';

class MainMenuOverlay extends ConsumerWidget {
  final PrismDropGame game;

  const MainMenuOverlay({super.key, required this.game});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final session = ref.watch(gameStateProvider);
    final notifier = ref.read(gameStateProvider.notifier);

    return SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 20),
          child: Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: const Color(0xFF0F172A).withValues(alpha: 0.94),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: const Color(0xFF38BDF8).withValues(alpha: 0.45),
                width: 2,
              ),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x6600F5D4),
                  blurRadius: 32,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'PRISM DROP',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 3.0,
                    color: Colors.white,
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  '2D PHYSICS GRAVITY MERGE',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 2.2,
                    color: Color(0xFF00F5D4),
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _StatPill(
                      icon: Icons.emoji_events_rounded,
                      label: 'BEST',
                      value: '${session.highScore}',
                      color: const Color(0xFFFFBE0B),
                    ),
                    _StatPill(
                      icon: Icons.monetization_on_rounded,
                      label: 'COINS',
                      value: '${session.coins}',
                      color: const Color(0xFF00F5D4),
                    ),
                  ],
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  height: 58,
                  child: ElevatedButton.icon(
                    onPressed: () {
                      AudioSynthesizerService.instance.playButtonClick();
                      game.startNewGame();
                    },
                    icon: const Icon(Icons.play_arrow_rounded, size: 30),
                    label: const Text(
                      'PLAY NOW',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 1.5,
                      ),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF00F5D4),
                      foregroundColor: const Color(0xFF070B14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          notifier.toggleSound();
                          AudioSynthesizerService.instance.playButtonClick();
                        },
                        icon: Icon(
                          session.soundEnabled
                              ? Icons.volume_up_rounded
                              : Icons.volume_off_rounded,
                        ),
                        label: Text(session.soundEnabled ? 'SOUND ON' : 'MUTED'),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: Color(0xFF334155)),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () {
                          notifier.toggleHaptics();
                          AudioSynthesizerService.instance.playButtonClick();
                        },
                        icon: Icon(
                          session.hapticsEnabled
                              ? Icons.vibration_rounded
                              : Icons.phone_android_rounded,
                        ),
                        label: Text(
                          session.hapticsEnabled ? 'HAPTICS ON' : 'HAPTICS OFF',
                        ),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: const BorderSide(color: Color(0xFF334155)),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                      ),
                    ),
                  ],
                ),
                if (!session.adsRemoved) ...[
                  const SizedBox(height: 16),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      onPressed: () {
                        AudioSynthesizerService.instance.playButtonClick();
                        IapService.instance.buyRemoveAds();
                      },
                      icon: const Icon(
                        Icons.block_rounded,
                        color: Color(0xFFF15BB5),
                      ),
                      label: Text(
                        'REMOVE ADS (${IapService.instance.removeAdsPriceLabel})',
                        style: const TextStyle(
                          fontWeight: FontWeight.w800,
                          color: Colors.white,
                        ),
                      ),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: Color(0xFFF15BB5)),
                        padding: const EdgeInsets.symmetric(vertical: 14),
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () => IapService.instance.restorePurchases(),
                    child: const Text(
                      'Restore Purchases',
                      style: TextStyle(color: Colors.white54, fontSize: 12),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _StatPill extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _StatPill({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF1E293B),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: Colors.white54,
                ),
              ),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
